import { exec } from 'child_process';
import { Client } from 'ssh2';
import chalk from 'chalk'; //命令行颜色
import ora from 'ora'; // 加载流程动画
import inquirer from 'inquirer';

const ssh2Client = new Client();
const config = {
  localPath: './assets.tar.gz',
  romotePath: '/root/web/assets.tar.gz',
  host: '129.211.164.125', // 主机地址
  port: 4000, // 项目部署端口
  username: 'root', // 服务器用户名
  password: 'chen220416!@#', // 服务器密码
};

// 压缩项目文件为zip包
const zipProject = () => {
  const loading = ora({
    text: '开始构建压缩包...',
  }).start();
  const zipShell =
    'tar --exclude node_modules --exclude logs --exclude dist -zcvf assets.tar.gz ./*';
  setTimeout(() => {
    const childProcess = exec(zipShell, (error, stdout, stderr) => {
      if (error) {
        console.log(`构建压缩包时出现异常${error}`);
        process.exit();
      }
      // console.log(`stdout: ${stdout}`);
      // console.error(`stderr: ${stderr}`);
    });
    childProcess.stdout.pipe(process.stdout);
    childProcess.on('exit', (code) => {
      loading.stop();
      console.log(chalk.green('项目文件压缩完成！开始上传压缩包至服务器'));
      uploadProjectFile(config.localPath, config.romotePath);
    });
  }, 3000);
};

// 上传压缩包到服务器
const uploadProjectFile = (localPath, romotePath) => {
  console.log('资源压缩完成，开始上传压缩包至服务器!');
  ssh2Client
    .on('ready', () => {
      const loading = ora({
        text: '服务器连接成功，开始上传资源。。。',
      }).start();
      ssh2Client.sftp((err, sftp) => {
        if (err) throw err;
        sftp.fastPut(localPath, romotePath, {}, (error, result) => {
          if (error) throw error;
          loading.stop();
          console.log(chalk.green('上传成功！，开始执行部署脚本！'));
          process.exit();
          // startDeploy();
        });
      });
    })
    .connect({
      host: config.host,
      port: 22,
      username: config.username,
      password: config.password,
    });
};

// 执行部署脚本
const startDeploy = () => {
  const shell = `
          cd /root/web
          if [ ! -d nice-todo-nest  ];then
            mkdir nice-todo-nest
          else
            rm -rf ./nice-todo-nest/*
          fi
          tar -zxvf assets.tar.gz -C ./nice-todo-nest
          rm -rf assets.tar.gz
          ls
          cd nice-todo-nest
          ls
          echo '开始安装依赖'
          npm install
          echo '开始打包镜像'
          sudo docker stop nice-todo-nest || true
          sudo docker rm nice-todo-nest || true
          sudo docker build -t nice-todo-nest .
          sudo docker run -d --privileged=true --name nice-todo-nest -p 4000:4000 -v /root/web/nice-todo-nest:/home/project nice-todo-nest
          docker ps
          exit
          `;
  ssh2Client.shell((err, stream) => {
    if (err) throw err;
    stream
      .end(shell)
      .on('data', (data) => {
        console.log(data.toString());
      })
      .on('close', () => {
        ssh2Client.end();
        console.log(chalk.green('部署成功!'));
      });
  });
};

// 执行交互后 启动发布程序
inquirer
  .prompt([
    {
      type: 'list',
      message: '请选择发布环境',
      name: 'env',
      choices: [
        {
          name: '测试环境',
          value: '测试环境',
        },
        {
          name: '正式环境',
          value: '正式环境',
        },
      ],
    },
  ])
  .then((answers) => {
    console.log(`开始构建${answers.env}....`);
    zipProject();
    // config = CONFIG[answers.env];
    // config.distFolder = config.distFolder ? config.distFolder : config.distFolder.replace("/", "");
    // //文件夹目录
    // distDir = path.resolve(__dirname, `${pathHierarchy + config.distFolder}`) //待打包
    // distZipPath = path.resolve(__dirname, `${pathHierarchy + config.distFolder}.zip`) //打包后地址(dist.zip是文件名,不需要更改, 主要在config中配置 PATH 即可)
    // checkConfig(config) // 检查
    // runUploadTask() // 发布
  });
