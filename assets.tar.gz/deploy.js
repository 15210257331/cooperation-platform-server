const { exec } = require('child_process');
const { Client } = require('ssh2');
const ssh2Client = new Client();

const localPath = './assets.tar.gz';
const romotePath = '/root/web/assets.tar.gz';
const shell = `
          cd /root/web
          if [ ! -d nice-todo-nest  ];then
            mkdir nice-todo-nest
          else
            rm -rf ./nice-todo-nest/*
          fi
          tar -zxvf assets.tar.gz -C ./nice-todo-nest
          rm -rf assets.tar.gz
          ls
          cd nice-todo-nest
          ls
          echo '开始安装依赖'
          npm install
          echo '开始打包镜像'
          sudo docker stop nice-todo-nest || true
          sudo docker rm nice-todo-nest || true
          sudo docker build -t nice-todo-nest .
          sudo docker run -d --privileged=true --name nice-todo-nest -p 4000:4000 -v /root/web/nice-todo-nest:/home/project nice-todo-nest
          docker ps
          exit
          `;

// 压缩打包项目文件
const buildProject = exec(
  'tar --exclude node_modules --exclude logs --exclude dist -zcvf assets.tar.gz ./* ',
  (error, stdout, stderr) => {
    if (error) {
      console.log(`构建压缩包时出现异常${error}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);
  },
);
buildProject.stdout.pipe(process.stdout);
// 监听进程的结束
buildProject.on('exit', () => {
  uploadProjectFile();
});

// 上传文件到服务器
function uploadProjectFile() {
  console.log('资源压缩完成，开始上传压缩包至服务器');
  ssh2Client
    .on('ready', () => {
      console.log('服务器连接成功！');
      ssh2Client.sftp((err, sftp) => {
        if (err) throw err;
        sftp.fastPut(localPath, romotePath, {}, (error, result) => {
          if (error) throw error;
          console.log('资源成功上传至服务器！，开始执行部署脚本！');
          ssh2Client.shell((err, stream) => {
            if (err) throw err;
            stream
              .end(shell)
              .on('data', (data) => {
                console.log(data.toString());
              })
              .on('close', () => {
                ssh2Client.end();
                console.log('部署成功,服务器连接已断开');
              });
          });
        });
      });
    })
    .connect({
      host: '129.211.164.125', // 服务器 host
      port: 22, // 服务器 port
      username: 'root', // 服务器用户名
      password: 'chen220416!@#', // 服务器密码
    });
}
