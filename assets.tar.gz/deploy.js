const child_process = require('child_process');
const { Client } = require('ssh2');
const inquirer = require('inquirer'); // 命令行交互

const ssh2Client = new Client();
const config = {
  localPath: './assets.tar.gz',
  romotePath: '/root/web/assets.tar.gz',
  host: '129.211.164.125', // 主机地址
  port: 4000, // 项目部署端口
  username: 'root', // 服务器用户名
  password: 'chen220416!@#', // 服务器密码
};

// 压缩项目文件为zip包
const zipProject = () => {
  const zipShell =
    'tar --exclude node_modules --exclude logs --exclude dist -zcvf assets.tar.gz ./*';
  setTimeout(() => {
    const childProcess = child_process.exec(
      zipShell,
      (error, stdout, stderr) => {
        if (error) {
          console.log(`构建压缩包时出现异常${error}`);
          process.exit();
        }
        // console.log(`stdout: ${stdout}`);
        // console.error(`stderr: ${stderr}`);
      },
    );
    childProcess.stdout.pipe(process.stdout);
    childProcess.on('exit', (code) => {
      console.log('项目文件压缩完成！开始上传压缩包至服务器');
      uploadProjectFile(config.localPath, config.romotePath);
    });
  }, 3000);
};

// 上传压缩包到服务器
const uploadProjectFile = (localPath, romotePath) => {
  console.log('资源压缩完成，开始上传压缩包至服务器!');
  ssh2Client
    .on('ready', () => {
      ssh2Client.sftp((err, sftp) => {
        if (err) throw err;
        sftp.fastPut(localPath, romotePath, {}, (error, result) => {
          if (error) throw error;
          console.log('上传成功！，开始执行部署脚本！');
          startDeploy();
        });
      });
    })
    .connect({
      host: config.host,
      port: 22,
      username: config.username,
      password: config.password,
    });
};

// 执行部署脚本
const startDeploy = () => {
  const shell = `
          cd /root/web
          if [ ! -d m-task-server  ];then
            mkdir m-task-server
          else
            rm -rf ./m-task-server/*
          fi
          tar -zxvf assets.tar.gz -C ./m-task-server
          rm -rf assets.tar.gz
          ls
          cd m-task-server
          ls
          echo '开始安装依赖'
          npm install --registry=https://registry.npm.taobao.org
          echo '开始打包镜像'
          sudo docker stop m-task-server || true
          sudo docker rm m-task-server || true
          sudo docker rmi m-task-server || true
          sudo docker build -t m-task-server .
          sudo docker run -d --privileged=true --name m-task-server -p 4000:4000 -v /root/web/m-task-server:/home/project m-task-server
          docker ps
          exit
          `;
  ssh2Client.shell((err, stream) => {
    if (err) throw err;
    stream
      .end(shell)
      .on('data', (data) => {
        console.log(data.toString());
      })
      .on('close', () => {
        ssh2Client.end();
        console.log('部署成功!');
        process.exit();
      });
  });
};

// 执行交互后 启动发布程序
inquirer
  .prompt([
    {
      type: 'list',
      message: '请选择发布环境',
      name: 'env',
      choices: [
        {
          name: '测试环境',
          value: '测试环境',
        },
        {
          name: '正式环境',
          value: '正式环境',
        },
      ],
    },
  ])
  .then((answers) => {
    console.log(`开始构建${answers.env}....`);
    zipProject();
  });
