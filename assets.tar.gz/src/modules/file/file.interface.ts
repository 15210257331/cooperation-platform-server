export interface UploadFileRo {
  filename: string;
  url: string;
}
